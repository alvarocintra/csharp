﻿namespace Modelos
{
    public class Endereco
    {
        public int EnderecoID { get; set; }
        public string Rua { get; set; }
        public int Numero { get; set; }
        public string Complemento { get; set; }
    }
}
