﻿namespace Modelos
{
    public class Cliente : Pessoa 
    {

    }
}
