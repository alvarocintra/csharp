﻿namespace Modelos
{
    public class Fornecedor : Pessoa
    {
    }
}
