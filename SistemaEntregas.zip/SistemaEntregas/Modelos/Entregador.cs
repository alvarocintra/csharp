﻿namespace Modelos
{
    public class Entregador : Pessoa
    {
    }
}
